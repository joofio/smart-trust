# GDHCNParticipantDID-XXC-UAT-All - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXC-UAT-All**

## Endpoint: GDHCNParticipantDID-XXC-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: UAT Participant XXC Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXC/did.json

**managingOrganization**: [Organization UAT Participant XXC](Organization-GDHCNParticipant-XXC-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXC-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "UAT Participant XXC Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXC-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXC"
}

```
