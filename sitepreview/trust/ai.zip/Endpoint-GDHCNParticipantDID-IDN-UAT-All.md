# GDHCNParticipantDID-IDN-UAT-All - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IDN-UAT-All**

## Endpoint: GDHCNParticipantDID-IDN-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Indonesia Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:IDN resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IDN/did.json

**managingOrganization**: [Organization Indonesia](Organization-GDHCNParticipant-IDN-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:IDN



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IDN-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Indonesia Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:IDN\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IDN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IDN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IDN"
}

```
