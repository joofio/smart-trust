# GDHCNParticipantDID-IDN-UAT-DSC - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IDN-UAT-DSC**

## Endpoint: GDHCNParticipantDID-IDN-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Indonesia Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:IDN:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IDN/DSC/did.json

**managingOrganization**: [Organization Indonesia](Organization-GDHCNParticipant-IDN-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:IDN:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IDN-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Indonesia Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:IDN:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IDN/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IDN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IDN:DSC"
}

```
