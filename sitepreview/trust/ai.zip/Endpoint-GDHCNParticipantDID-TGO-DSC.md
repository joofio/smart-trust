# GDHCNParticipantDID-TGO-DSC - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-TGO-DSC**

## Endpoint: GDHCNParticipantDID-TGO-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Togo Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:TGO:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/TGO/DSC/did.json

**managingOrganization**: [Organization Togo](Organization-GDHCNParticipant-TGO.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:TGO:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-TGO-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Togo Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:TGO:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/TGO/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-TGO"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:TGO:DSC"
}

```
