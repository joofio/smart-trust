# GDHCNParticipantDID-OMN-UAT-DSC - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-OMN-UAT-DSC**

## Endpoint: GDHCNParticipantDID-OMN-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Oman Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:OMN:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/OMN/DSC/did.json

**managingOrganization**: [Organization Oman](Organization-GDHCNParticipant-OMN-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:OMN:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-OMN-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Oman Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:OMN:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/OMN/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-OMN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:OMN:DSC"
}

```
