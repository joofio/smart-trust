# GDHCNParticipantDID-BLZ-DEV-DSC - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BLZ-DEV-DSC**

## Endpoint: GDHCNParticipantDID-BLZ-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Belize Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:BLZ:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BLZ/DSC/did.json

**managingOrganization**: [Organization Belize](Organization-GDHCNParticipant-BLZ-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:BLZ:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BLZ-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Belize Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:BLZ:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BLZ/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BLZ-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:BLZ:DSC"
}

```
