# GDHCNParticipantDID-XXA-UAT-DSC - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXA-UAT-DSC**

## Endpoint: GDHCNParticipantDID-XXA-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: UAT Participant XXA Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXA:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXA/DSC/did.json

**managingOrganization**: [Organization UAT Participant XXA](Organization-GDHCNParticipant-XXA-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXA:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXA-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "UAT Participant XXA Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXA:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXA/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXA-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXA:DSC"
}

```
