# GDHCNParticipantDID-ESP-UAT-SCA - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-ESP-UAT-SCA**

## Endpoint: GDHCNParticipantDID-ESP-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Spain Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:ESP:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/ESP/SCA/did.json

**managingOrganization**: [Organization Spain](Organization-GDHCNParticipant-ESP-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:ESP:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-ESP-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Spain Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:ESP:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/ESP/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-ESP-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:ESP:SCA"
}

```
